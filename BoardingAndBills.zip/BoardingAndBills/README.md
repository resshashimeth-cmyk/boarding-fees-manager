# Boarding & Bills – Android app

The Boarding House Ledger and Bills We Paid in one Android app. It works offline and keeps
its data file in your Google Drive.

## Ways to build the app (APK)

**A. Ask Claude in a new chat (easiest)**
Start a new chat, attach this zip file, and say: "Build this Android app into an APK".
(The Android download sites you allowed in Settings work in new chats.)

**B. GitHub (free, no software to install)**
1. Make a free account at github.com and create a new repository.
2. Upload everything in this folder (keep the `.github` folder).
3. Open the **Actions** tab. When "Build Android app" turns green, open it and download
   **BoardingAndBills-apk**. Inside is `app-debug.apk`.

**C. Android Studio on a computer**
Open this folder in Android Studio, then choose Build → Build APK(s).

## Installing on the phone
Copy the APK to the phone, open it, and allow "Install unknown apps" when Android asks.

## First time on the phone
1. Open **Boarding & Bills**.
2. Press **Open data file** at the top and choose `Boarding and Bills - data.json`
   from Google Drive.
3. From then on the app opens that file by itself, and every change saves back to it.
   The green bar at the bottom shows when it was last saved.
