package lk.boardingbills.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Boarding & Bills: the web app from assets/index.html in a WebView, with a small
 * bridge so the data file can live in Google Drive (picked once through the
 * Android file picker, then saved to automatically).
 */
public class MainActivity extends Activity {

    private static final int REQ_FILE_CHOOSER = 1;
    private static final int REQ_OPEN_DATA = 2;
    private static final int REQ_CREATE_DATA = 3;
    private static final int REQ_SAVE_FILE = 4;

    private static final String PREFS = "boarding_bills";
    private static final String KEY_DATA_URI = "data_uri";
    private static final String KEY_DATA_NAME = "data_name";

    private WebView web;
    private WebView printView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private String pendingData;
    private String pendingFileData;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setDatabaseEnabled(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("file".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme)
                        || "about".equals(scheme)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                openChooser(params);
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /* ---------- photo / file chooser for <input type=file> ---------- */

    private void openChooser(WebChromeClient.FileChooserParams params) {
        Intent pick = params.createIntent();
        String[] types = params.getAcceptTypes();
        boolean wantsImage = false;
        for (String t : types) {
            if (t != null && (t.startsWith("image") || t.isEmpty())) {
                wantsImage = true;
            }
        }
        // Allow photos and PDFs when the page asks for "image/*,application/pdf"
        if (types.length > 1) {
            pick = new Intent(Intent.ACTION_GET_CONTENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
            List<String> mimes = new ArrayList<>();
            for (String t : types) {
                for (String part : t.split(",")) {
                    String p = part.trim();
                    if (p.startsWith(".")) {
                        p = p.equals(".json") ? "application/json" : "";
                    }
                    if (!p.isEmpty()) {
                        mimes.add(p);
                    }
                }
            }
            if (!mimes.isEmpty()) {
                pick.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
            }
        }

        List<Intent> extra = new ArrayList<>();
        cameraUri = null;
        if (wantsImage) {
            try {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, "bill_" + System.currentTimeMillis() + ".jpg");
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                if (cameraUri != null) {
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    extra.add(cam);
                }
            } catch (Exception e) {
                cameraUri = null;
            }
        }

        Intent chooser = Intent.createChooser(pick, "Choose a bill photo or file");
        if (!extra.isEmpty()) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toArray(new Intent[0]));
        }
        try {
            startActivityForResult(chooser, REQ_FILE_CHOOSER);
        } catch (ActivityNotFoundException e) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
    }

    /* ---------- results ---------- */

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (fileCallback == null) {
                return;
            }
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i = 0; i < n; i++) {
                        result[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                } else if (cameraUri != null) {
                    result = new Uri[]{cameraUri};
                }
            } else if (cameraUri != null) {
                try {
                    getContentResolver().delete(cameraUri, null, null);
                } catch (Exception ignored) {
                }
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            return;
        }

        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == REQ_CREATE_DATA) {
                js("window.__androidSaved&&window.__androidSaved(false,'')");
            }
            return;
        }
        final Uri uri = data.getData();

        if (requestCode == REQ_OPEN_DATA) {
            keepPermission(uri, data.getFlags());
            rememberDataFile(uri);
            io.execute(() -> {
                try {
                    String text = readText(uri);
                    String name = displayName(uri);
                    js("window.__androidOpened&&window.__androidOpened(" + JSONObject.quote(text) + ","
                            + JSONObject.quote(name) + ")");
                } catch (Exception e) {
                    toast("Could not open that file.");
                }
            });
        } else if (requestCode == REQ_CREATE_DATA) {
            keepPermission(uri, data.getFlags());
            rememberDataFile(uri);
            final String text = pendingData;
            pendingData = null;
            writeAsync(uri, text, true);
        } else if (requestCode == REQ_SAVE_FILE) {
            final String text = pendingFileData;
            pendingFileData = null;
            io.execute(() -> {
                try {
                    writeText(uri, text);
                    toast("Saved.");
                } catch (Exception e) {
                    toast("Could not save that file.");
                }
            });
        }
    }

    /* ---------- helpers ---------- */

    private void keepPermission(Uri uri, int flags) {
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
        }
    }

    private void rememberDataFile(Uri uri) {
        prefs.edit()
                .putString(KEY_DATA_URI, uri.toString())
                .putString(KEY_DATA_NAME, displayName(uri))
                .apply();
    }

    private Uri dataUri() {
        String u = prefs.getString(KEY_DATA_URI, null);
        return u == null ? null : Uri.parse(u);
    }

    private String displayName(Uri uri) {
        String name = "";
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
                null, null, null)) {
            if (c != null && c.moveToFirst()) {
                name = c.getString(0);
            }
        } catch (Exception ignored) {
        }
        return name == null ? "" : name;
    }

    private String readText(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) {
                throw new Exception("no stream");
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void writeText(Uri uri, String text) throws Exception {
        OutputStream out;
        try {
            out = getContentResolver().openOutputStream(uri, "wt");
        } catch (Exception e) {
            out = getContentResolver().openOutputStream(uri, "w");
        }
        if (out == null) {
            throw new Exception("no stream");
        }
        try (OutputStream o = out) {
            o.write(text.getBytes(StandardCharsets.UTF_8));
            o.flush();
        }
    }

    private void writeAsync(final Uri uri, final String text, final boolean report) {
        if (text == null) {
            return;
        }
        io.execute(() -> {
            boolean ok;
            try {
                writeText(uri, text);
                ok = true;
            } catch (Exception e) {
                ok = false;
            }
            if (report) {
                js("window.__androidSaved&&window.__androidSaved(" + ok + ","
                        + JSONObject.quote(prefs.getString(KEY_DATA_NAME, "")) + ")");
            }
        });
    }

    private void js(final String script) {
        main.post(() -> web.evaluateJavascript(script, null));
    }

    private void toast(final String msg) {
        main.post(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private void createDocument(String name, String mime, int request) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, request);
    }

    private void printHtml(final String html, final String title) {
        printView = new WebView(this);
        printView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(title);
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4).build();
                pm.print(title, adapter, attrs);
            }
        });
        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    /* ---------- the bridge the page calls ---------- */

    private class Bridge {

        @JavascriptInterface
        public boolean hasDataFile() {
            return dataUri() != null;
        }

        @JavascriptInterface
        public String dataFileName() {
            return prefs.getString(KEY_DATA_NAME, "");
        }

        /** Reads the remembered data file; "" if there is none or it cannot be read. */
        @JavascriptInterface
        public String loadData() {
            Uri u = dataUri();
            if (u == null) {
                return "";
            }
            try {
                return readText(u);
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void openData() {
            main.post(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream", "text/plain"});
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_OPEN_DATA);
            });
        }

        /**
         * Saves the data. With a remembered file it writes there; otherwise, when
         * askIfNone is true, it asks where to create the data file.
         */
        @JavascriptInterface
        public void saveData(final String json, final boolean askIfNone) {
            final Uri u = dataUri();
            if (u != null) {
                writeAsync(u, json, true);
            } else if (askIfNone) {
                main.post(() -> {
                    pendingData = json;
                    createDocument("Boarding and Bills - data.json", "application/json", REQ_CREATE_DATA);
                });
            }
        }

        /** Forget the remembered data file (to pick a different one). */
        @JavascriptInterface
        public void forgetDataFile() {
            prefs.edit().remove(KEY_DATA_URI).remove(KEY_DATA_NAME).apply();
        }

        @JavascriptInterface
        public void saveFile(final String name, final String data, final String mime) {
            main.post(() -> {
                pendingFileData = data;
                createDocument(name, mime == null || mime.isEmpty() ? "application/octet-stream" : mime, REQ_SAVE_FILE);
            });
        }

        @JavascriptInterface
        public void print(final String html, final String title) {
            main.post(() -> printHtml(html, title == null || title.isEmpty() ? "Boarding & Bills" : title));
        }
    }
}
